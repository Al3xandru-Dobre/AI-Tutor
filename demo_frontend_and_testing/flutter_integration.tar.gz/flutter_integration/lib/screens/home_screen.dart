import 'package:flutter/material.dart';

void main() {
  runApp(const JapaneseTutorApp());
}

class JapaneseTutorApp extends StatelessWidget {
  const JapaneseTutorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Japanese AI Tutor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0f172a),
        fontFamily: 'Inter',
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool isSidebarCollapsed = false;
  bool isInternetSearchEnabled = true;
  bool isAdvancedRAGEnabled = false;
  final TextEditingController _messageController = TextEditingController();
  final List<ChatMessage> _messages = [];
  final List<ConversationItem> _conversations = [
    ConversationItem(
      title: 'Learning Hiragana Basics',
      date: 'Today',
      isActive: true,
    ),
    ConversationItem(
      title: 'Japanese Grammar Questions',
      date: 'Yesterday',
      isActive: false,
    ),
    ConversationItem(
      title: 'Cultural Traditions Discussion',
      date: '2 days ago',
      isActive: false,
    ),
  ];

  @override
  void initState() {
    super.initState();
    // Add a sample message
    _messages.add(
      ChatMessage(
        content: 'こんにちは！ Welcome! How can I help you learn Japanese today?',
        isUser: false,
      ),
    );
  }

  void _sendMessage() {
    if (_messageController.text.trim().isEmpty) return;

    setState(() {
      _messages.add(ChatMessage(
        content: _messageController.text,
        isUser: true,
      ));
      _messageController.clear();
      
      // Simulate AI response
      Future.delayed(const Duration(milliseconds: 800), () {
        setState(() {
          _messages.add(ChatMessage(
            content: 'Great question! Let me explain that in detail...',
            isUser: false,
          ));
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0f172a),
              Color(0xFF1e1b4b),
              Color(0xFF0f172a),
            ],
          ),
        ),
        child: Row(
          children: [
            // Sidebar
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: isSidebarCollapsed ? 0 : 280,
              child: isSidebarCollapsed
                  ? const SizedBox.shrink()
                  : _buildSidebar(),
            ),
            
            // Main Content
            Expanded(
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(
                    child: _messages.isEmpty
                        ? _buildEmptyState()
                        : _buildChatContainer(),
                  ),
                  _buildInputArea(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSidebar() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0f172a).withOpacity(0.95),
        border: const Border(
          right: BorderSide(color: Color(0xFF334155), width: 1),
        ),
      ),
      child: Column(
        children: [
          // Sidebar Header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0xFF334155), width: 1),
              ),
            ),
            child: Column(
              children: [
                _buildGradientButton(
                  icon: Icons.add,
                  text: 'New Chat',
                  colors: const [Color(0xFF6366f1), Color(0xFF8b5cf6)],
                  onTap: () {
                    setState(() {
                      _messages.clear();
                    });
                  },
                ),
                const SizedBox(height: 12),
                _buildGradientButton(
                  icon: Icons.auto_awesome,
                  text: 'AI Document Generator',
                  colors: const [Color(0xFFf59e0b), Color(0xFFd97706)],
                  onTap: () {
                    // Show document generator
                  },
                ),
              ],
            ),
          ),

          // Recent Conversations
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(20, 16, 20, 8),
                  child: Text(
                    'RECENT CONVERSATIONS',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF94a3b8),
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    itemCount: _conversations.length,
                    itemBuilder: (context, index) {
                      return _buildConversationItem(_conversations[index]);
                    },
                  ),
                ),
              ],
            ),
          ),

          // About Section
          Container(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(color: Color(0xFF334155), width: 1),
              ),
              color: Color(0xFF0f172a),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ABOUT',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF94a3b8),
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    const Text(
                      'Japanese AI Tutor',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFFcbd5e1),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF6366f1).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text(
                        'v1.5',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF6366f1),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Your personal AI-powered Japanese learning companion!',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFcbd5e1),
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.only(top: 12),
                  decoration: const BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: Color(0x1A94a3b8),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      _buildAboutLink('Help'),
                      const SizedBox(width: 12),
                      _buildAboutLink('Settings'),
                      const SizedBox(width: 12),
                      _buildAboutLink('Feedback'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGradientButton({
    required IconData icon,
    required String text,
    required List<Color> colors,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: colors,
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: colors[0].withOpacity(0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 18, color: Colors.white),
            const SizedBox(width: 8),
            Text(
              text,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConversationItem(ConversationItem item) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        gradient: item.isActive
            ? const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF6366f1), Color(0xFF8b5cf6)],
              )
            : null,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {},
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: item.isActive ? FontWeight.w500 : FontWeight.w400,
                    color: item.isActive
                        ? Colors.white
                        : const Color(0xFFcbd5e1),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  item.date,
                  style: TextStyle(
                    fontSize: 11,
                    color: item.isActive
                        ? Colors.white.withOpacity(0.7)
                        : const Color(0xFF94a3b8),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAboutLink(String text) {
    return InkWell(
      onTap: () {},
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 12,
          color: Color(0xFF94a3b8),
          decoration: TextDecoration.none,
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 20),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF6366f1),
            Color(0xFF8b5cf6),
            Color(0xFFec4899),
          ],
        ),
      ),
      child: Row(
        children: [
          // Sidebar Toggle
          Material(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            child: InkWell(
              onTap: () {
                setState(() {
                  isSidebarCollapsed = !isSidebarCollapsed;
                });
              },
              borderRadius: BorderRadius.circular(8),
              child: const Padding(
                padding: EdgeInsets.all(8),
                child: Icon(
                  Icons.menu,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ),
          
          // Title
          const Expanded(
            child: Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '🇯🇵',
                    style: TextStyle(fontSize: 24),
                  ),
                  SizedBox(width: 12),
                  Text(
                    'Japanese AI Tutor',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Export Button
          Material(
            color: Colors.white.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
            child: InkWell(
              onTap: () {},
              borderRadius: BorderRadius.circular(10),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.download,
                      color: Colors.white,
                      size: 18,
                    ),
                    SizedBox(width: 8),
                    Text(
                      'Export',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [Color(0xFF6366f1), Color(0xFFec4899)],
            ).createShader(bounds),
            child: const Text(
              'Welcome to your Japanese learning journey!',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Start exploring the beautiful world of Japanese\nlanguage and culture. Ask me anything!',
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF94a3b8),
              height: 1.6,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildChatContainer() {
    return ListView.builder(
      padding: const EdgeInsets.all(24),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        return _buildMessage(_messages[index]);
      },
    );
  }

  Widget _buildMessage(ChatMessage message) {
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.7,
        ),
        decoration: BoxDecoration(
          gradient: message.isUser
              ? const LinearGradient(
                  colors: [Color(0xFF6366f1), Color(0xFF8b5cf6)],
                )
              : null,
          color: message.isUser ? null : const Color(0xFF1e293b),
          borderRadius: BorderRadius.circular(16),
          border: message.isUser
              ? null
              : Border.all(color: const Color(0xFF334155)),
        ),
        child: Text(
          message.content,
          style: const TextStyle(
            fontSize: 15,
            color: Colors.white,
            height: 1.5,
          ),
        ),
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF0f172a).withOpacity(0.6),
        border: const Border(
          top: BorderSide(color: Color(0xFF334155), width: 1),
        ),
      ),
      child: Column(
        children: [
          // Suggestion buttons (showing briefly)
          _buildSuggestionButtons(),
          const SizedBox(height: 16),
          
          // Input container
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1e293b),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF334155)),
            ),
            child: Row(
              children: [
                // Internet Toggle
                _buildToggleButton(
                  isEnabled: isInternetSearchEnabled,
                  icon: Icons.language,
                  onTap: () {
                    setState(() {
                      isInternetSearchEnabled = !isInternetSearchEnabled;
                    });
                  },
                ),
                
                // Advanced RAG Toggle
                _buildToggleButton(
                  isEnabled: isAdvancedRAGEnabled,
                  icon: Icons.science,
                  onTap: () {
                    setState(() {
                      isAdvancedRAGEnabled = !isAdvancedRAGEnabled;
                    });
                  },
                ),
                
                // Text Input
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    maxLines: null,
                    style: const TextStyle(
                      color: Color(0xFFf8fafc),
                      fontSize: 15,
                    ),
                    decoration: const InputDecoration(
                      hintText: 'Ask me anything about Japanese...',
                      hintStyle: TextStyle(
                        color: Color(0xFF94a3b8),
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                
                // Send Button
                Container(
                  margin: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF6366f1), Color(0xFF8b5cf6)],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: _sendMessage,
                      borderRadius: BorderRadius.circular(10),
                      child: const Padding(
                        padding: EdgeInsets.all(10),
                        child: Icon(
                          Icons.send,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSuggestionButtons() {
    final suggestions = [
      'Get started on Grammar',
      'Numbers & Counting',
      'Food',
      'Directions',
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: suggestions.map((suggestion) {
        return Material(
          color: const Color(0xFF6366f1).withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          child: InkWell(
            onTap: () {
              _messageController.text = suggestion;
            },
            borderRadius: BorderRadius.circular(8),
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 8,
              ),
              decoration: BoxDecoration(
                border: Border.all(
                  color: const Color(0xFF6366f1).withOpacity(0.2),
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                suggestion,
                style: const TextStyle(
                  fontSize: 13,
                  color: Color(0xFFcbd5e1),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildToggleButton({
    required bool isEnabled,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Material(
      color: isEnabled
          ? const Color(0xFF10b981).withOpacity(0.2)
          : Colors.transparent,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Icon(
            icon,
            color: isEnabled
                ? const Color(0xFF10b981)
                : const Color(0xFF94a3b8),
            size: 20,
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }
}

class ChatMessage {
  final String content;
  final bool isUser;

  ChatMessage({
    required this.content,
    required this.isUser,
  });
}

class ConversationItem {
  final String title;
  final String date;
  final bool isActive;

  ConversationItem({
    required this.title,
    required this.date,
    required this.isActive,
  });
}
