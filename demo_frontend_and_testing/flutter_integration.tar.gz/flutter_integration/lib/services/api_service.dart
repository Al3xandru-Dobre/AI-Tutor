import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../models/chat_message.dart';
import '../models/conversation.dart';

class ApiService {
  final http.Client _client = http.Client();

  // ============================================
  // CHAT ENDPOINTS
  // ============================================

  /// Send a chat message and get AI response
  /// Matches: POST /api/chat from backend
  Future<Map<String, dynamic>> sendMessage({
    required String message,
    String? conversationId,
    bool internetSearch = true,
    bool advancedRAG = false,
    String userLevel = 'beginner',
  }) async {
    try {
      ApiConfig.log('Sending message: $message');
      
      final response = await _client
          .post(
            Uri.parse('${ApiConfig.baseUrl}${ApiConfig.chatEndpoint}'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'message': message,
              if (conversationId != null) 'conversationId': conversationId,
              'internetSearch': internetSearch,
              'advancedRAG': advancedRAG,
              'level': userLevel,
            }),
          )
          .timeout(ApiConfig.receiveTimeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        ApiConfig.log('Response received: ${data['response']?.substring(0, 50)}...');
        
        return {
          'conversationId': data['conversationId'],
          'response': data['response'],
          'sources': data['sources'],
          'searchPerformed': data['searchPerformed'],
          'metadata': data['metadata'],
        };
      } else {
        throw Exception('Failed to send message: ${response.statusCode}');
      }
    } catch (e) {
      ApiConfig.log('Error sending message: $e');
      rethrow;
    }
  }

  // ============================================
  // CONVERSATION ENDPOINTS
  // ============================================

  /// Get all conversations
  /// Matches: GET /api/conversations
  Future<List<Conversation>> getConversations() async {
    try {
      ApiConfig.log('Fetching all conversations');
      
      final response = await _client
          .get(Uri.parse('${ApiConfig.baseUrl}${ApiConfig.conversationsEndpoint}'))
          .timeout(ApiConfig.connectionTimeout);

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        final conversations = data.map((json) => Conversation.fromJson(json)).toList();
        
        ApiConfig.log('Loaded ${conversations.length} conversations');
        return conversations;
      } else {
        throw Exception('Failed to load conversations: ${response.statusCode}');
      }
    } catch (e) {
      ApiConfig.log('Error loading conversations: $e');
      rethrow;
    }
  }

  /// Get a specific conversation by ID
  /// Matches: GET /api/conversations/:id
  Future<Conversation> getConversation(String id) async {
    try {
      ApiConfig.log('Fetching conversation: $id');
      
      final response = await _client
          .get(Uri.parse('${ApiConfig.baseUrl}${ApiConfig.conversationsEndpoint}/$id'))
          .timeout(ApiConfig.connectionTimeout);

      if (response.statusCode == 200) {
        final conversation = Conversation.fromJson(jsonDecode(response.body));
        ApiConfig.log('Loaded conversation with ${conversation.messages.length} messages');
        return conversation;
      } else {
        throw Exception('Failed to load conversation: ${response.statusCode}');
      }
    } catch (e) {
      ApiConfig.log('Error loading conversation: $e');
      rethrow;
    }
  }

  /// Delete a conversation
  /// Matches: DELETE /api/conversations/:id
  Future<void> deleteConversation(String id) async {
    try {
      ApiConfig.log('Deleting conversation: $id');
      
      final response = await _client
          .delete(Uri.parse('${ApiConfig.baseUrl}${ApiConfig.conversationsEndpoint}/$id'))
          .timeout(ApiConfig.connectionTimeout);

      if (response.statusCode == 200) {
        ApiConfig.log('Conversation deleted successfully');
      } else {
        throw Exception('Failed to delete conversation: ${response.statusCode}');
      }
    } catch (e) {
      ApiConfig.log('Error deleting conversation: $e');
      rethrow;
    }
  }

  /// Delete all conversations
  /// Matches: DELETE /api/conversations
  Future<void> deleteAllConversations() async {
    try {
      ApiConfig.log('Deleting all conversations');
      
      final response = await _client
          .delete(Uri.parse('${ApiConfig.baseUrl}${ApiConfig.conversationsEndpoint}'))
          .timeout(ApiConfig.connectionTimeout);

      if (response.statusCode == 200) {
        ApiConfig.log('All conversations deleted');
      } else {
        throw Exception('Failed to delete all conversations');
      }
    } catch (e) {
      ApiConfig.log('Error deleting all conversations: $e');
      rethrow;
    }
  }

  // ============================================
  // HEALTH & STATUS ENDPOINTS
  // ============================================

  /// Check API health
  /// Matches: GET /api/health
  Future<Map<String, dynamic>> checkHealth() async {
    try {
      final response = await _client
          .get(Uri.parse('${ApiConfig.baseUrl}${ApiConfig.healthEndpoint}'))
          .timeout(ApiConfig.connectionTimeout);

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Health check failed');
      }
    } catch (e) {
      ApiConfig.log('Health check error: $e');
      rethrow;
    }
  }

  /// Get RAG statistics
  /// Matches: GET /api/rag/stats
  Future<Map<String, dynamic>> getRAGStats() async {
    try {
      final response = await _client
          .get(Uri.parse('${ApiConfig.baseUrl}${ApiConfig.ragStatsEndpoint}'))
          .timeout(ApiConfig.connectionTimeout);

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get RAG stats');
      }
    } catch (e) {
      ApiConfig.log('Error getting RAG stats: $e');
      rethrow;
    }
  }

  /// Get internet search status
  /// Matches: GET /api/internet/status
  Future<Map<String, dynamic>> getInternetStatus() async {
    try {
      final response = await _client
          .get(Uri.parse('${ApiConfig.baseUrl}${ApiConfig.internetStatusEndpoint}'))
          .timeout(ApiConfig.connectionTimeout);

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get internet status');
      }
    } catch (e) {
      ApiConfig.log('Error getting internet status: $e');
      rethrow;
    }
  }

  /// Check ChromaDB health
  /// Matches: GET /api/chromadb/health
  Future<Map<String, dynamic>> getChromaDBHealth() async {
    try {
      final response = await _client
          .get(Uri.parse('${ApiConfig.baseUrl}${ApiConfig.chromadbHealthEndpoint}'))
          .timeout(ApiConfig.connectionTimeout);

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get ChromaDB health');
      }
    } catch (e) {
      ApiConfig.log('Error getting ChromaDB health: $e');
      rethrow;
    }
  }

  // ============================================
  // DOCUMENT GENERATION ENDPOINTS
  // ============================================

  /// Generate PDF from conversation
  /// Matches: POST /api/documents/generate/pdf
  Future<void> generatePDF(String conversationId) async {
    try {
      ApiConfig.log('Generating PDF for conversation: $conversationId');
      
      final response = await _client.post(
        Uri.parse('${ApiConfig.baseUrl}/documents/generate/pdf'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'conversationId': conversationId}),
      ).timeout(ApiConfig.receiveTimeout);

      if (response.statusCode != 200) {
        throw Exception('Failed to generate PDF');
      }
    } catch (e) {
      ApiConfig.log('Error generating PDF: $e');
      rethrow;
    }
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  /// Test connection to backend
  Future<bool> testConnection() async {
    try {
      final health = await checkHealth();
      return health['status'] == 'healthy';
    } catch (e) {
      return false;
    }
  }

  /// Dispose of HTTP client
  void dispose() {
    _client.close();
  }
}
