class ApiConfig {
  // Configurare URL Backend
  // Modifică în funcție de unde rulează backend-ul
  
  // Pentru development local
  static const String baseUrl = 'http://localhost:3000/api';
  
  // Pentru Android emulator (localhost pe emulator = 10.0.2.2)
  // static const String baseUrl = 'http://10.0.2.2:3000/api';
  
  // Pentru device fizic (înlocuiește cu IP-ul computerului tău)
  // static const String baseUrl = 'http://192.168.1.100:3000/api';
  
  // Endpoints din backend
  static const String chatEndpoint = '/chat';
  static const String conversationsEndpoint = '/conversations';
  static const String healthEndpoint = '/health';
  static const String ragStatsEndpoint = '/rag/stats';
  static const String internetStatusEndpoint = '/internet/status';
  static const String chromadbHealthEndpoint = '/chromadb/health';
  
  // Timeouts
  static const Duration connectionTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 60);
  
  // Debug mode
  static const bool debugMode = true;
  
  static void log(String message) {
    if (debugMode) {
      print('[API] $message');
    }
  }
}
